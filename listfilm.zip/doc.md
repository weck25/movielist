
# MOVIELIST
### THIS PROJECT CREATED FROM TUTORIAL YOUTUBE DEAAFRIZAL : https://www.youtube.com/watch?v=QV4qKaeEf9c

Title: movie list
Description: simple movie information list
Installation: Instructions on how to install the project.
Usage: Instructions on how to use the project.
Contributing: Guidelines for contributing to the project.
License: The license under which the project is released.

# Project Title

movie list using api tmdb : https://themoviedb.org

## Installation

`npm install`

## Usage

edit .env.example to your api_key and token

## Contributing

clone this project and edit what ever you whant

## License

The license under which the project is released.